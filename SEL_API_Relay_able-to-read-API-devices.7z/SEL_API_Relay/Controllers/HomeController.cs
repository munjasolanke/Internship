﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SEL_API_Relay.Models;
using Newtonsoft.Json;
using System.Net.Http;

namespace SEL_API_Relay.Controllers
{
    public class HomeController : Controller
    {
        /*private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        */

        /*
            These lines are needed to use the Database context,
            define the connection to the API, and use the
            HttpClient to request data from the API
        */

        //Base URL for the SEL API. Method specific URLs are appended to this base URL.
        string BASE_URL = "http://localhost:5230/";
        HttpClient httpClient;

        /*
         These lines create a Constructor for the HomeController.
         Then, the Database context is defined in a variable.
         Then, an instance of the HttpClient is created.
        */
        public HomeController()
        {
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new
                System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

 //       public List<Relay_Models> GetRelay_Models()
        public Relay_Models GetRelay_Models()
        {
            string SEL_Database_API_PATH = BASE_URL + "api/device";
            string Relay_Models_List = "";
            //List<Relay_Models> relay_Models = null;
            Relay_Models relay_Models = null;


            //Connect to SEL Database API and retrieve the information 
            httpClient.BaseAddress = new Uri(SEL_Database_API_PATH);

            try
            {
                HttpResponseMessage response = httpClient.GetAsync(SEL_Database_API_PATH).GetAwaiter().GetResult();

                //Read the Json objects in the API response
                if (response.IsSuccessStatusCode)
                {
                    Relay_Models_List = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                }

                //Now parse Json string to C# objects
                if (!Relay_Models_List.Equals(""))
                {
                    relay_Models = JsonConvert.DeserializeObject<Relay_Models>(Relay_Models_List);
                    //relay_Models = relay_Models.GetRange(0, 10);
                }
            }
            catch(Exception e)
            {
                // This is a useful place to insert a breakpoint and observe the error message
                Console.WriteLine(e.Message);
            }

            return relay_Models;
        }


        public IActionResult Index()
        {
            Relay_Models relay_Models = GetRelay_Models();

            return View(relay_Models);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
